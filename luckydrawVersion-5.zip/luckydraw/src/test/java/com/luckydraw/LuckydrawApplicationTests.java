package com.luckydraw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuckydrawApplicationTests {

	@Test
	void contextLoads() {
	}

}
